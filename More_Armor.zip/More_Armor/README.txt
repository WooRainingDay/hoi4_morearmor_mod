# More Armor Mod for Hearts of Iron IV

## What This Mod Does:

### 1. Increased Armor & Engine Upgrades
- **Max armor level**: 100 (vanilla: 25)
- **Max engine level**: 100 (vanilla: 25)
- **No reliability penalty** at any level
- armor_tech_5 and engine_tech_5 unlock level 100

### 2. Increased Division Limit for Generals
- Generals with "Skilled Staffer" trait can command **100 divisions** (vanilla: 30)
- Base divisions: 24
- With trait: 100 total

## Installation:

This mod should already be in your mod folder. Just:
1. Launch Hearts of Iron IV
2. Go to the Mods menu in the launcher
3. Enable "More_Armor"
4. Play!

## Files Modified:

- `common/units/equipment/land_upgrades.txt` - Armor & Engine upgrades
- `common/unit_leader/01_division_limit.txt` - Division limits

## Compatibility:

- Compatible with most mods
- May conflict with mods that modify the same files
- Not compatible with Ironman mode (achievements disabled)

## Version: 1.17

Enjoy your super-powered tanks and armies!
